# YL-INF1399-week01
Demo repository for INF1399 assignment 2
